import matplotlib.pyplot as plt
import numpy as np
from matplotlib.gridspec import GridSpec

energy_dos, dos, idos = np.loadtxt('fesi_dos.dat', unpack=True)
band_data = np.loadtxt('B2-FeSi_bands.dat.gnu')

k = np.unique(band_data[:, 0])
bands = np.reshape(band_data[:, 1], (-1, len(k)))

fermi = 18.1136

fig = plt.figure(figsize=(9, 5), constrained_layout=True)
gs = GridSpec(1, 2, width_ratios=[3, 1.2], figure=fig)

# plot bandas
ax_band = fig.add_subplot(gs[0])
for band in bands:
    ax_band.plot(k, band, color='black', linewidth=0.8, alpha=0.8)
ax_band.axhline(fermi, linestyle='--', linewidth=0.75, color='k', alpha=0.5)

ax_band.text(k[-5], fermi + 0.05, 'Energia de Fermi', fontsize=9,
             verticalalignment='bottom', horizontalalignment='right', color='k')

xticks = [0, 0.5000, 1.2071, 1.5133, 2.0996]
xlabels = ['L', r'$\Gamma$', 'X', 'U', r'$\Gamma$']
ax_band.set_xticks(xticks)
ax_band.set_xticklabels(xlabels)

ax_band.set_ylabel("Energia (eV)")
ax_band.set_xlabel(r"$\vec{k}$")
ax_band.set_xlim(min(k), max(k))
ax_band.set_ylim(15, 20)
ax_band.tick_params(direction='in')
ax_band.grid(True, linestyle=':', linewidth=0.3, axis='y', alpha=0.5)

# plot DOS
ax_dos = fig.add_subplot(gs[1], sharey=ax_band)
ax_dos.plot(dos, energy_dos, color='red', linewidth=0.8)
ax_dos.fill_betweenx(energy_dos, 0, dos, where=(energy_dos < fermi), color='red', alpha=0.3)
ax_dos.axhline(fermi, linestyle='--', linewidth=0.75, color='k', alpha=0.5)

ax_dos.set_xlabel("DOS")
ax_dos.set_xlim(left=0)
ax_dos.set_ylim(15, 20)

plt.setp(ax_dos.get_yticklabels(), visible=False)

# Título
plt.suptitle("Estrutura de Bandas e DOS do FeSi B2", fontsize=12)
plt.show()

